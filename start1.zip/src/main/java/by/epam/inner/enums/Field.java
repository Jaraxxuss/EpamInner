package by.epam.inner.enums;

public enum Field {
    DATE,NAME,PRICE,NUMBER,DISCOUNT;
}
