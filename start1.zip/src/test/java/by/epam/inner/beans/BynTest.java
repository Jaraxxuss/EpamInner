package by.epam.inner.beans;

import org.junit.Test;

import static org.junit.Assert.*;

public class BynTest {

    @Test
    public void toString1() {
    }

    @Test
    public void equals1() {
    }

    @Test
    public void mul() {
    }

    @Test
    public void sub() {
    }
}